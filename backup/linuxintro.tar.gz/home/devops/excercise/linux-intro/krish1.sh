cd $1
/home/devops/excercise/linux-intro/test.sh > gayatri
cp gayatri .hiddenfile
