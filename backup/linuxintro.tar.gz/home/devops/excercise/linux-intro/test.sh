echo " Gayatri "
pwd
